

import pytest
from project import add_expense, remove_expense, list_expenses, total_expenses, expenses

def test_add_expense():
    
    expenses.clear()
    add_expense("Lunch", 10.5)
    assert len(expenses) == 1
    assert expenses[0]["description"] == "Lunch"
    assert expenses[0]["amount"] == 10.5

def test_remove_expense():
    
    expenses.clear()
    add_expense("Lunch", 10.5)
    add_expense("Dinner", 20.0)
    remove_expense("Lunch")
    assert len(expenses) == 1
    assert expenses[0]["description"] == "Dinner"

def test_list_expenses(capsys):
    
    expenses.clear()
    add_expense("Lunch", 10.5)
    add_expense("Dinner", 20.0)
    list_expenses()
    captured = capsys.readouterr()
    assert "Lunch: $10.5" in captured.out
    assert "Dinner: $20.0" in captured.out

def test_total_expenses(capsys):
    
    expenses.clear()
    add_expense("Lunch", 10.5)
    add_expense("Dinner", 20.0)
    total_expenses()
    captured = capsys.readouterr()
    assert "Total expenses: $30.5" in captured.out

if __name__ == "__main__":
    pytest.main()
