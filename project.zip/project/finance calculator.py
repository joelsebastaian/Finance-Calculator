# project.py

import sys

expenses = []

def main():
    while True:
        user_choice = input("Enter a command (add, remove, list, total, exit): ").strip().lower()
        if user_choice == "add":
            add_expense()
        elif user_choice == "remove":
            remove_expense()
        elif user_choice == "list":
            list_expenses()
        elif user_choice == "total":
            total_expenses()
        elif user_choice == "exit":
            sys.exit(0)
        else:
            print("Invalid command")

def add_expense():
    description = input("Enter the description of the expense: ").strip()
    amount = float(input("Enter the amount of the expense: ").strip())
    expenses.append({"description": description, "amount": amount})
    print("Expense added!")

def remove_expense():
    description = input("Enter the description of the expense to remove: ").strip()
    global expenses
    expenses = [expense for expense in expenses if expense["description"] != description]
    print("Expense removed!")

def list_expenses():
    if not expenses:
        print("No expenses recorded.")
        return
    for expense in expenses:
        print(f"{expense['description']}: ${expense['amount']}")

def total_expenses():
    total = sum(expense["amount"] for expense in expenses)
    print(f"Total expenses: ${total}")

if __name__ == "__main__":
    main()
